<template>
  <HelloWorld
    msg="Only now, you can get all premium features & more with the best discounts of the year."
  />
</template>

<script setup lang="ts">
import HelloWorld from "../components/HelloWorld.vue";
</script>
